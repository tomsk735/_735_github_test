
// file for debugging medianFilter(...). See medianFilterW3.c

#define ARRAY_SIZE  5

extern   int medianFilter( int outArray[], int inArray[], int ArraySize );   // medianFilterW3.c

//-----------------------------------------------------
void main(void){
  int array[ ARRAY_SIZE ] = {1, -3, 2, 3, 8 };
  int FiltArray[ ARRAY_SIZE ];
  int N,
      err = 0;
  
  N = ARRAY_SIZE;
  
  err = medianFilter( FiltArray,  array, N ); 
  
//goodbye >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  
  err = err;
  for(;;);   // == while(1);
  
}// main